##!/bin/bash
##Removes txt2pdf#############
##sh uninstall.sh
##by joelcfq@yandex.ru #######
##############################
VM=`tput setaf 1` #vermelho
VD=`tput setaf 2` #verde
NM=`tput sgr0`    #normal
sudo rm /usr/bin/txt2pdf
sudo rm /usr/share/applications/txt2pdf.desktop
sudo rm -rf /usr/share/txt2pdf
echo "${VM}txt2pdf was removed from computer!${NM}"
