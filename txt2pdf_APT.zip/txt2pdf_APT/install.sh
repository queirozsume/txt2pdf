##!/bin/bash
##txt2pdf requires:###########
##sudo apt install enscript
##sudo apt install ghostscript
##sh txt2pdf.sh
##by joelcfq@yandex.ru #######
##############################
VM=`tput setaf 1` #vermelho
VD=`tput setaf 2` #verde
NM=`tput sgr0`    #normal
sudo apt -y install ghostscript --quiet
sudo apt -y install enscript --quiet
sudo cp resources/txt2pdf /usr/bin
sudo cp resources/txt2pdf.desktop /usr/share/applications
sudo mkdir /usr/share/txt2pdf
sudo cp resources/txt2pdf.sh /usr/share/txt2pdf
echo "${VD}Now, txt2pdf is installed!${NM}"
