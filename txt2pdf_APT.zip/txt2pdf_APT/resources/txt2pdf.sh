##!/bin/bash
##txt2pdf requires:###########
##sudo apt install enscript
##sudo apt install ghostscript
##sh txt2pdf.sh
##by joelcfq@yandex.ru #######
##############################

converte(){
	cat $arquivo.txt | iconv -c -f utf-8 -t ISO-8859-1 | enscript -o $arquivo.ps --no-header --font="Times-Roman12" --title $arquivo --quiet --margins=85.03937007873901:56.692913385826:85.03937007873901:56.692913385826
	ps2pdf $arquivo.ps $arquivo.pdf
	rm $arquivo.ps
}

VM=`tput setaf 1` #vermelho
VD=`tput setaf 2` #verde
NM=`tput sgr0`    #normal

read -p "Insert filename (no extension): " arquivo

tamanho=${#arquivo}

if [ -f "$arquivo.txt" ]
then
	converte $arquivo
	echo "${VD}The pdf is in the same folder as the txt!${NM}"
else
	echo "${VM}You must to insert the correct filename without .txt!${NM}"
fi



